Verification for Lantern substitutions in a genus-two fibration on a Dolgachev surface

Run: python3 verify_lanterns.py
Dependencies: flipper, sympy (install with python3 -m pip install flipper sympy).
The script uses exact mapping-class actions and integral matrices, with no
random search, numerical tolerances, or external data files. It verifies the
Section 7 Gurtas chain calculation, retains every separating twist, and tests
the complete twenty-seven-move list and both lantern lifts. Curve equality
is unoriented geometric equality. Homology is used separately to resolve
the hyperelliptic lift and calculate the integral quotient.

The mathematical passage from the column quotient to the total-space H1
uses the primitive-fiber lemma in the article. The geometry script does not establish the MY/Gurtas marked comparison.

The pi1 directory supplies a separate, dependency-free verification of
the full group pi_1(Z)=Z/2. See pi1/README.txt. Run
  python3 pi1/compute_orbifold.py
  python3 pi1/verify_reduction.py
The first command regenerates the fourteen geometric relators. The second
checks the relation consequences, the reverse map onto the Klein four-group,
and all integral vanishing-cycle classes. The proof identifying the actual
total-space group uses the already established nonzero H1 to rule out a
trivial clutching quotient.

Verified dependency versions: flipper 0.15.6, sympy 1.14.0.
