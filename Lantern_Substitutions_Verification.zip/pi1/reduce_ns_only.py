import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def red(w):
 s=[]
 for x in w:
  if s and s[-1]==x:s.pop()
  else:s.append(x)
 return tuple(s)
def cyclic(w):
 w=red(w)
 while len(w)>1 and w[0]==w[-1]:w=w[1:-1]
 return w

def minrot(w):
 n=len(w)
 if not n:return ()
 s=w+w;i,j,k=0,1,0
 while i<n and j<n and k<n:
  a,b=s[i+k],s[j+k]
  if a==b:k+=1;continue
  if a>b:i=i+k+1;i+=i==j
  else:j=j+k+1;j+=i==j
  k=0
 a=min(i,j);return s[a:a+n]
def canon(w):
 w=cyclic(w)
 return min(minrot(w),minrot(w[::-1]))
D=json.loads((ROOT/'orbifold_relators.json').read_text())
rels=[canon(tuple(range(1,7)))]+[canon(tuple(w)) for w in D['relations'][:6]+D['relations'][-3:]]
cert=[]
pool={r for r in rels if 0<len(r)<=100}
for rnd in range(15):
 print('round',rnd,'lengths',[len(w)for w in rels],flush=True)
 parent=list(range(7))
 def root(a):
  while parent[a]!=a:a=parent[a]
  return a
 equalities=sorted(r for r in pool if len(r)==2)
 for a,b in equalities:
  a,b=root(a),root(b)
  if a!=b:parent[max(a,b)]=min(a,b)
 for ii,old in enumerate(rels):
  new=canon(tuple(root(x)for x in old))
  if new!=old:
   cert.append({'kind':'identification','target':ii,'before':list(old),'after':list(new),'equalities':[list(r)for r in equalities]})
   rels[ii]=new
   if 0<len(new)<=100:pool.add(new)
 rules={}
 for i,r in enumerate(sorted(pool,key=lambda w:(len(w),w))):
  n=len(r)
  if not n or n>100:continue
  k=n//2+1
  for rr in [r,r[::-1]]:
   for p in range(n):
    rot=rr[p:]+rr[:p];lhs=rot[:k];rhs=rot[k:][::-1]
    rules.setdefault((k,lhs),[]).append((i,rhs,r))
 lens=sorted({k for k,_ in rules})
 changed=False
 for i,w in enumerate(rels):
  while True:
   hit=False
   # cyclic shifts are allowed before every relator replacement.
   n=len(w)
   for p in range(n):
    for k in lens:
     if k>n:break
     ww=w+w[:k-1];key=(k,ww[p:p+k])
     opts=rules.get(key,())
     match=next(((j,r,rw) for j,r,rw in opts if rw!=w),None)
     if match is None:continue
     j,rhs,ruleword=match;rot=w[p:]+w[:p];new=canon(rhs+rot[k:])
     cert.append({'target':i,'rule':j,'offset':p,'cut':k,'ruleword':list(ruleword),'before':list(w),'after':list(new)})
     w=new
     if 0<len(w)<=100:pool.add(w)
     changed=True;hit=True;break
    if hit:break
   if not hit:break
  rels[i]=w
 if not changed:break
(ROOT/'ns_seed.json').write_text(json.dumps({'terminal':[list(w)for w in rels],'steps':cert,'consequences':[list(w)for w in sorted(pool,key=lambda w:(len(w),w))]}))
print('terminal',rels,'steps',len(cert))
