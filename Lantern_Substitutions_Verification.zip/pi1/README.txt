Fundamental group of the two-lantern fibration

Result: pi_1(Z)=Z/2 for the Gurtas chain factorization in Section 7.

This is a separate computation from the MY-marking comparison, which remains
unresolved. No identification of the two source markings is asserted.

The calculation uses the sphere orbifold group on six involutions q_i, with
q_1...q_6=1. Its even-word subgroup is the genus-two surface group. The standard
chain twist acts by the Artin automorphism q_i -> q_i q_(i+1) q_i,
q_(i+1) -> q_i. A standard nonseparating curve is q_i q_(i+1); the separator S
is (q_1 q_2 q_3)^2. Exact transport of the fifteen first-stage cycles, parking
all five separating cycles, and the twenty-seven moves gives the eleven
surviving cycles. The three new cycles are pulled back from (c_3,M,S) by G.

Run from any directory, using Python 3 without additional packages:
  python3 pi1/compute_orbifold.py
  python3 pi1/verify_reduction.py

compute_orbifold.py regenerates orbifold_relators.json. verify_reduction.py
independently replays the two stored relation-consequence certificates. It
checks every replacement, the five short consequences, the reverse map onto
the Klein four-group, and every vanishing class against the integral matrix.

The first certificate has 307 steps and the second has 3303 steps. These are
consequences of the original relators; no claim of a confluent rewriting
system is needed. No random search or floating point calculation is used.
The even subgroup of the resulting Klein four-group is Z/2. The total-space
group is a quotient of that subgroup. The nonzero H1 already proved in the
article excludes the trivial quotient, without a section assumption.

To regenerate the consequence certificates, run reduce_ns_only.py first,
then reduce_orbifold.py. Those two scripts search for shortening replacements;
the independent verifier checks the stored result and does not trust the search.
