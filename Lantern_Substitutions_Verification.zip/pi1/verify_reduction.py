"""Replay consequences using only involution cancellation and relator replacement."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def free_reduce(word):
 out=[]
 for x in word:
  if out and out[-1]==x:out.pop()
  else:out.append(x)
 return tuple(out)
def cyclic_reduce(word):
 w=free_reduce(word);i,j=0,len(w)
 while j-i>1 and w[i]==w[j-1]:i+=1;j-=1
 return w[i:j]
def least_rotation(w):
 # Duval's factorization algorithm, independent of the generator's Booth code.
 if not w:return ()
 s=w+w;n=len(w);i=0;answer=0
 while i<n:
  answer=i;j=i+1;k=i
  while j<2*n and s[k]<=s[j]:
   k=i if s[k]<s[j] else k+1
   j+=1
  while i<=k:i+=j-k
 return s[answer:answer+n]
def canonical(word):
 w=cyclic_reduce(word)
 return min(least_rotation(w),least_rotation(w[::-1]))
def same_conjugacy(w,v):
 w=cyclic_reduce(w)
 if len(w)!=len(v):return False
 if not w:return True
 ss=''.join(map(str,w));tt=''.join(map(str,v))
 return tt in ss+ss or tt in ss[::-1]+ss[::-1]
D=json.loads((ROOT/'orbifold_relators.json').read_text())
known={canonical(tuple(range(1,7)))}|{canonical(tuple(w)) for w in D['relations']}
for filename in ['ns_seed.json','reduction.json']:
 data=json.loads((ROOT/filename).read_text())
 for n,step in enumerate(data['steps']):
  before=tuple(step['before']);after=tuple(step['after'])
  assert before in known,(filename,n,'unknown target')
  if step.get('kind')=='identification':
   parents=list(range(7))
   def root(x):
    while parents[x]!=x:x=parents[x]
    return x
   for eq in step['equalities']:
    assert tuple(eq) in known and len(eq)==2
    a,b=map(root,eq);parents[max(a,b)]=min(a,b)
   assert same_conjugacy(tuple(root(x) for x in before),after)
  else:
   rule=tuple(step['ruleword']);assert rule in known
   i,k=step['offset'],step['cut'];rot=before[i:]+before[:i]
   valid=False
   for rr in [rule,rule[::-1]]:
    for j in range(len(rule)):
     r=rr[j:]+rr[:j]
     if r[:k]==rot[:k] and same_conjugacy(r[k:][::-1]+rot[k:],after):
      valid=True;break
    if valid:break
   assert valid,(filename,n,'invalid replacement')
  known.add(after)
 print('PASS:',filename,len(data['steps']),'exact consequences')
required=[(1,3),(1,5),(2,4),(5,6),(1,2,1,2)]
assert all(canonical(w) in known for w in required)
# Reverse bound: every original relator holds in the Klein four-group.
A={1,3,5,6};B={2,4}
for w in [list(range(1,7))]+D['relations']:
 assert sum(x in A for x in w)%2==0
 assert sum(x in B for x in w)%2==0
print('PASS: orbifold quotient is exactly V4; even subgroup is Z/2.')
# Independent abelian calibration in the article's (a,b,c,d) basis.
# Schreier generators y_i=q_i q_6 have the following classes.
Y={1:(0,1,0,1),2:(-1,1,0,1),3:(-1,0,0,1),4:(0,0,-1,1),5:(0,0,-1,0),6:(0,0,0,0)}
def homology(w):
 assert len(w)%2==0
 return tuple(sum((1 if k%2==0 else -1)*Y[x][j]for k,x in enumerate(w))for j in range(4))
expected=[(10,-7,16,5),(25,-29,52,22),(64,-75,134,57),(3,-4,7,3),(0,2,-3,-2),(1,-2,3,1)]+[(0,0,0,0)]*5+[(0,1,-1,-1),(2,-1,3,1),(0,0,0,0)]
for w,v in zip(D['relations'],expected):
 actual=homology(w)
 assert actual==v or actual==tuple(-x for x in v)
print('PASS: all fourteen relators match the integral vanishing-cycle classes.')
