#!/usr/bin/env python3
"""Exact checks for Section 7 of Lantern substitutions in a genus-two fibration on a Dolgachev surface.

Requires flipper and sympy. Products act rightmost first. SB_6 denotes the
six-punctured-sphere quotient; its half twists lift to genus-two Dehn twists.
Curve comparisons use unoriented geometric coordinates, tuple(curve).
Sphere identities are supplemented by integral homology to exclude the
hyperelliptic kernel. This code does not identify the MY and Gurtas markings
and does not compute the full fundamental group.
"""
import flipper, functools, math, itertools
surf=flipper.load('SB_6');cs=[surf.laminations[n] for n in 'abcde'];ts=[surf.mapping_classes['s_'+str(i)] for i in range(5)]
prod=lambda a:functools.reduce(lambda x,y:x*y,a)
app=lambda ww,cc:prod([ts[i-1] if i>0 else ts[-i-1].inverse() for i in ww])(cc)
B=app([1,2,3,4],cs[4]);L=app([1,1,2,3],cs[3]);M=app([2,1,1,2],cs[2]);TS=(ts[0]*ts[1])**6;phi=ts[0]*ts[1]
cache={};icache={}
def tw(x):
 key=tuple(x)
 if key not in cache:cache[key]=x.encode_halftwist()
 return cache[key]
g=tw(M).inverse();rho=app([-4],cs[4]);e=app([-3,1,-2,5,4,3],cs[1]);st=ts[1].inverse()*ts[2].inverse()*TS*ts[2]*ts[1]
base=[M,g(B),M,g(B),g(e),g(st.inverse()(rho)),phi(B),phi(L),phi(B),phi(L)]
ip=lambda a,b:a[0]*b[1]-a[1]*b[0]+a[2]*b[3]-a[3]*b[2]
def norm(a):
 for x in a:
  if x:return tuple(-z for z in a) if x<0 else tuple(a)
 return tuple(a)
def tv(a,b,sg=1):return norm(tuple(y+sg*ip(a,b)*x for x,y in zip(a,b)))
cols=[(1,0,1,0),(2,-1,2,-1),(1,0,1,0),(2,-1,2,-1),(1,-2,2,-1),(1,0,0,-1),(1,1,0,1),(1,0,1,1),(1,1,0,1),(1,0,1,1)]
def move(w,vs,i,sg):
 x,y=w[i:i+2];a,b=vs[i:i+2]
 pair=(tw(x)(y),x) if sg==1 else(y,tw(y).inverse()(x))
 cp=(tv(a,b),a) if sg==1 else(b,tv(b,a,-1))
 return w[:i]+list(pair)+w[i+2:],vs[:i]+list(cp)+vs[i+2:]
def inter(x,y):
 key=tuple(sorted([tuple(x),tuple(y)]))
 if key not in icache:icache[key]=x.geometric_intersection(y)
 return icache[key]
def primitive(a,b):return math.gcd(*(abs(a[i]*b[j]-a[j]*b[i])for i,j in itertools.combinations(range(4),2)))==1
from sympy import Matrix,ZZ
from sympy.matrices.normalforms import smith_normal_form
T=lambda x:tw(x)
Phip=phi
W=T(B)*T(L)*T(M)*TS
assert (W**2).is_identity()
u=g(L);v=phi(M)
assert inter(u,v)==0
assert W*TS==TS*W
# Actual first lantern. h=t_M normalizes the cut pair.
assert T(u)**2*T(v)**2 == g*T(e)*T(st.inverse()(rho))*(T(e)*st*T(e).inverse())*g.inverse()
# W fixes all original vanishing curves, which validates cyclic block reordering.
for X in [B,L,M]:assert tuple(W(X))==tuple(X)
sg=g*TS*g.inverse();sprime=phi*TS*phi.inverse();star=g*T(e)*st*T(e).inverse()*g.inverse()
# P=(M,gS,gB), Q=(S',B',L'), so first substitution gives PP e_raw rho_alt_raw star QQ.
P=[('n',M,T(M)),('s',None,sg),('n',g(B),T(g(B)))]
Q=[('s',None,sprime),('n',phi(B),T(phi(B))),('n',phi(L),T(phi(L)))]
full=P+P+[('n',g(e),T(g(e))),('n',g(st.inverse()(rho)),T(g(st.inverse()(rho)))),('s',None,star)]+Q+Q
assert prod([x[2] for x in full]).is_identity()
# Move all five separating twists right. For (s,n), inverse Hurwitz gives (n,n^-1 s n).
for i in range(len(full)):
 for j in range(len(full)-1):
  if full[j][0]=='s' and full[j+1][0]=='n':
   s,n=full[j:j+2];full[j:j+2]=[n,('s',None,n[2].inverse()*s[2]*n[2])]
assert [x[0]for x in full]==['n']*10+['s']*5
assert [tuple(x[1])for x in full[:10]]==[tuple(x)for x in base]
assert prod([x[2]for x in full]).is_identity()
rec={'normalized_path': [[3, -1], [2, 1], [5, -1], [3, 1], [8, -1], [0, 1], [6, -1], [8, -1], [5, 1], [4, -1], [2, -1], [4, 1], [5, -1], [5, -1], [0, -1], [3, -1], [2, -1], [1, -1], [5, -1], [4, -1], [3, -1], [2, -1], [7, -1], [6, -1], [5, -1], [4, -1], [3, -1]]};ww=list(base);vv=list(cols)
for i,sgn in rec['normalized_path']:
 x,y=full[i:i+2]
 if sgn==1:
  yy=x[2](y[1]);full[i:i+2]=[('n',yy,T(yy)),x]
 else:
  xx=y[2].inverse()(x[1]);full[i:i+2]=[y,('n',xx,T(xx))]
 ww,vv=move(ww,vv,i,sgn)
assert [tuple(x[1])for x in full[:10]]==[tuple(x)for x in ww]
assert prod([x[2]for x in full]).is_identity()
assert tuple(ww[0])==tuple(ww[1]) and tuple(ww[2])==tuple(ww[3])
assert inter(ww[0],ww[2])==0 and primitive(vv[0],vv[2])
# Lift: source W² is identity in genus2 because sphere identity and Sp4 lift I, not -I.
def trans(v):
 J=Matrix([[0,1,0,0],[-1,0,0,0],[0,0,0,1],[0,0,-1,0]])
 v=Matrix(v);return Matrix.eye(4)+v*(v.T*J)
WM=trans((0,1,0,1))*trans((1,1,1,1))*trans((1,0,1,0))
assert WM**2==Matrix.eye(4)
# Every following step is a genuine Hurwitz move or genuine local lantern on a cut system.
post=vv[4:]+[tuple(a+b for a,b in zip(vv[0],vv[2])),tuple(a-b for a,b in zip(vv[0],vv[2]))]
SNF=smith_normal_form(Matrix.hstack(*map(Matrix,post)),domain=ZZ)

# Short geometric words for the repeated second boundary and its standardization.
RR=app([5,5,5,4,-3],cs[1])
GG=prod([ts[1],ts[0].inverse(),ts[3],ts[2],ts[4]**-2,ts[1].inverse()])
assert tuple(ww[0])==tuple(M)
assert tuple(ww[2])==tuple(RR)
assert tuple(GG(M))==tuple(cs[0])
assert tuple(GG(RR))==tuple(cs[4])
# Standard second lantern in the sphere quotient.
assert ts[0]**2*ts[4]**2 == ts[2]*T(M)*TS
# Verify the lifts of BOTH lantern identities on integral homology.
cv=[Matrix(v) for v in [(1,0,0,0),(0,1,0,0),(1,0,-1,0),(0,0,0,1),(0,0,1,0)]]
TT=[trans(v) for v in cv]
def homword(seq,x):
 for n in seq[::-1]:x=(TT[n-1] if n>0 else TT[-n-1].inv())*x
 return x
BB=homword([1,2,3,4],cv[4]);LL=homword([1,1,2,3],cv[3])
MM=homword([2,1,1,2],cv[2]);PP=TT[0]*TT[1]
u_hom=trans(MM).inv()*LL;v_hom=PP*MM
assert ip(tuple(u_hom),tuple(v_hom))==0
assert primitive(tuple(u_hom),tuple(v_hom))
rh=homword([-4],cv[4]);ee=homword([-3,1,-2,5,4,3],cv[1])
assert trans(LL)**2*trans(trans(MM)*PP*MM)**2==trans(rh)*trans(ee)
assert TT[0]**2*TT[4]**2==TT[2]*trans(MM)
# Integral homology obstruction.
AA=Matrix([[10,25,64,3,0,1,2,0],[-7,-29,-75,-4,2,-2,-1,1],
 [16,52,134,7,-3,3,3,-1],[5,22,57,3,-2,1,1,-1]])
actual=Matrix.hstack(*map(Matrix,post))
assert all(actual[:,i] in [AA[:,i],-AA[:,i]] for i in range(8))
assert AA[:,:4].det()==2
assert all(sum(AA[j,i] for j in [0,1,3])%2==0 for i in range(8))
assert [abs(SNF[i,i]) for i in range(4)]==[1,1,1,2]
print('PASS: first lantern, full positive word, all 27 moves, geometric second cut,')
print('      second lantern and genus-two lifts, homology matrix, Smith (1,1,1,2).')
