"""Verify the geometric extractions, homology and parity checks in Section 7."""
import itertools
import subprocess
import sys
import tempfile
from pathlib import Path

import flipper
from sympy import Matrix, ZZ
from sympy.matrices.normalforms import smith_normal_form

ROOT = Path(__file__).resolve().parent
CHAIN = [(1,0,0,0), (0,1,0,0), (1,0,-1,0), (0,0,0,1), (0,0,1,0)]
MOVES = [
    (3,-1), (2,1), (5,-1), (3,1), (8,-1), (0,1), (6,-1), (8,-1), (5,1),
    (4,-1), (2,-1), (4,1), (5,-1), (5,-1), (0,-1), (3,-1), (2,-1),
    (1,-1), (5,-1), (4,-1), (3,-1), (2,-1), (7,-1), (6,-1), (5,-1),
    (4,-1), (3,-1),
]
MARKINGS = {
    2: (2,-1,4,3,-5,-5,-2), 6: (2,-1,4,3,-2),
    10: (-4,2,-1,3,-2), 14: (2,-1,4,3,5,5,5,5,-2),
}
EXPECTED_MATRICES = {
    6: [[6,-17,-44,-3,2,-1,0,2], [-3,21,55,4,-2,2,1,-1],
        [4,-4,-10,-1,1,-1,1,1], [1,-14,-37,-3,0,-1,-1,1]],
    10: [[2,-9,-24,-3,4,-1,2,0], [1,13,35,4,-6,2,-1,1],
         [8,12,34,5,-3,1,-1,3], [-3,-6,-17,-3,2,-1,1,-1]],
    14: [[-2,-1,-4,-3,6,-1,0,2], [5,5,15,4,-10,2,1,-1],
         [28,-4,-2,11,-15,3,5,-3], [-7,2,3,-3,4,-1,-1,1]],
}
SHORT_RELATORS = {
    6: ("1232323215", "4145", "1232123215"),
    10: ("656123232321", "124542", "4123212321424542"),
    14: ("6565656123232321", "4146565656", "1232123216565656"),
}

surface = flipper.load("SB_6")
curves = [surface.laminations[name] for name in "abcde"]
twists = [surface.mapping_classes[f"s_{i}"] for i in range(5)]


def twist(a, b, power=1):
    pairing = a[0]*b[1] - a[1]*b[0] + a[2]*b[3] - a[3]*b[2]
    return tuple(y + power*pairing*x for x, y in zip(a,b))


def action(word, curve):
    for i in reversed(word):
        mapping = twists[abs(i)-1]
        curve = (mapping if i > 0 else mapping.inverse())(curve)
    return curve


def hom_action(word, vector):
    for i in reversed(word):
        vector = twist(CHAIN[abs(i)-1], vector, 1 if i > 0 else -1)
    return vector


def initial_curves():
    b_curve = action((1,2,3,4), curves[4])
    l_curve = action((1,1,2,3), curves[3])
    m_curve = action((2,1,1,2), curves[2])
    inverse_m = m_curve.encode_halftwist().inverse()
    rho = action((-4,), curves[4])
    epsilon = action((-3,1,-2,5,4,3), curves[1])
    separator = (twists[0]*twists[1])**6
    conjugator = twists[1].inverse()*twists[2].inverse()
    first = inverse_m(epsilon)
    second = inverse_m((conjugator*separator*conjugator.inverse()).inverse()(rho))
    b_prime = action((1,2), b_curve)
    l_prime = action((1,2), l_curve)
    return [m_curve, inverse_m(b_curve)]*2 + [first,second] + [b_prime,l_prime]*2


def initial_classes():
    b_class = hom_action((1,2,3,4), CHAIN[4])
    l_class = hom_action((1,1,2,3), CHAIN[3])
    m_class = hom_action((2,1,1,2), CHAIN[2])
    first = twist(m_class, hom_action((-3,1,-2,5,4,3), CHAIN[1]), -1)
    second = twist(m_class, hom_action((-4,), CHAIN[4]), -1)
    return ([m_class, twist(m_class,b_class,-1)]*2 + [first,second]
            + [hom_action((1,2),b_class),hom_action((1,2),l_class)]*2)


def oriented(vector):
    return tuple(-x for x in vector) if next((x for x in vector if x), 1) < 0 else vector


def transported_classes(power):
    vectors = initial_classes()
    vectors[6:] = [twist(CHAIN[4],v,power) for v in vectors[6:]]
    for i, sign in MOVES:
        a,b = vectors[i:i+2]
        pair = (twist(a,b),a) if sign == 1 else (b,twist(b,a,-1))
        vectors[i:i+2] = map(oriented,pair)
    return vectors


def verify_geometry(order, power):
    cycles = initial_curves()
    cycles[6:] = [(twists[4]**power)(curve) for curve in cycles[6:]]
    for i, sign in MOVES:
        a,b = cycles[i:i+2]
        cycles[i:i+2] = ([a.encode_halftwist()(b),a] if sign == 1
                          else [b,b.encode_halftwist().inverse()(a)])
    actual = [tuple(action(MARKINGS[order],curve)) for curve in cycles[:4]]
    assert actual == [tuple(curves[i]) for i in (0,0,4,4)]
    v = action((1,2,2,1,1,2),curves[2])
    h = (1,2,2,-3,1,-2)
    assert tuple(action(h,curves[0])) == tuple(v)
    assert tuple(action(h,curves[4])) == tuple(curves[4])
    assert v.geometric_intersection(curves[4]) == 0


def verify_homology(order, power):
    columns = transported_classes(power)[4:]
    inverse = tuple(-i for i in reversed(MARKINGS[order]))
    columns += [hom_action(inverse,CHAIN[2]),
                hom_action(inverse,hom_action((2,1,1,2),CHAIN[2]))]
    matrix = Matrix(columns).T
    if order in EXPECTED_MATRICES:
        expected = Matrix(EXPECTED_MATRICES[order])
        assert all(matrix[:,i] in (expected[:,i],-expected[:,i]) for i in range(8))
    smith = smith_normal_form(matrix, domain=ZZ)
    assert [abs(smith[i,i]) for i in range(4)] == [1,1,1,order]
    print(f"Order {order}: Smith invariants (1, 1, 1, {order})")


def verify_parity():
    for power in (0,1):
        vectors = transported_classes(power)
        mod_two = lambda v: tuple(x % 2 for x in v)
        assert mod_two(vectors[0]) == mod_two(vectors[1])
        assert mod_two(vectors[2]) == mod_two(vectors[3])
        a,b = vectors[0],vectors[2]
        interiors = tuple(x+y for x,y in zip(a,b))
        assert all((v[0]+v[1]+v[3]) % 2 == 0 for v in vectors[4:]+[interiors])
    print("Both parities: the functional (1,1,0,1) kills the cycle span")


def verify_relator_inputs():
    import json
    with tempfile.TemporaryDirectory() as directory:
        for order, expected in SHORT_RELATORS.items():
            output = Path(directory)/f"relators_{order}.json"
            subprocess.run([sys.executable, str(ROOT/"pi1"/"compute_orbifold.py"),
                            "--order",str(order),"--output",str(output)],
                           check=True,stdout=subprocess.DEVNULL)
            relators = json.loads(output.read_text())["relations"]
            digits = lambda i: "".join(map(str,relators[i]))
            assert tuple(digits(i) for i in (5,11,12)) == expected
            assert digits(10) == "132156123"*2
            print(f"Order {order}: orbifold words in the paper verified")


if __name__ == "__main__":
    for order in MARKINGS:
        power = -(order-2)//2
        verify_geometry(order,power)
        verify_homology(order,power)
    verify_parity()
    verify_relator_inputs()
