"""Verify the finite images and the rank-two representation in Section 8."""
import json
from collections import deque
from pathlib import Path

from sympy import Matrix, eye

ROOT = Path(__file__).resolve().parent
COLUMNS = [
    (10,-7,16,5), (25,-29,52,22), (64,-75,134,57), (3,-4,7,3),
    (0,2,-3,-2), (1,-2,3,1), (2,-1,3,1), (0,1,-1,-1),
]
IDENTITY = tuple(int(i % 5 == 0) for i in range(16))


def finite_image(modulus):
    generators = []
    for a,b,c,d in COLUMNS:
        vector = (a,b,c,d)
        covector = (-b,a,-d,c)
        generators.append(tuple(
            (IDENTITY[4*i+j] + vector[i]*covector[j]) % modulus
            for i in range(4) for j in range(4)
        ))
    queue = deque([IDENTITY])
    group = {IDENTITY}
    while queue:
        left = queue.popleft()
        for right in generators:
            product = tuple(
                sum(left[4*i+k]*right[4*k+j] for k in range(4)) % modulus
                for i in range(4) for j in range(4)
            )
            if product not in group:
                group.add(product)
                queue.append(product)
    return group


def verify_finite_images():
    group_two = finite_image(2)
    group_four = finite_image(4)
    assert len(group_two) == 24 and len(group_four) == 12288
    assert {tuple(x % 2 for x in g) for g in group_four} == group_two
    kernel = [g for g in group_four if tuple(x % 2 for x in g) == IDENTITY]
    assert len(kernel) == 512
    for g in kernel:
        b = [(x-y)//2 for x,y in zip(g,IDENTITY)]
        # lambda=(1,1,1,0) and lambda^T J=(-1,1,0,1).
        assert (-sum(b[:3])+sum(b[4:7])+sum(b[12:15])) % 2 == 0
    print("Section 8: orders 24 and 12288, kernel of order 512 with the stated equation")


def verify_rank_two():
    data = json.loads((ROOT/"pi1"/"orbifold_relators.json").read_text())
    words = data["relations"][-3:] + data["relations"][:-3]
    kinds = data["kinds"][-3:] + data["kinds"][:-3]
    reflections = {1:(0,0), 3:(1,0), 5:(0,1), 6:(-1,1)}
    slopes = [(2,1),(4,1),(1,0),(-1,1),(1,2),(1,1),(1,1),
              (5,2),(3,1),(11,4),(0,0),(3,1),(1,0),(0,0)]
    assert len(words) == len(kinds) == len(slopes)
    product = eye(2)
    for word, kind, (p,q) in zip(words,kinds,slopes):
        x=y=0
        sign=1
        for letter in word:
            if letter in reflections:
                u,v = reflections[letter]
                x += sign*u
                y += sign*v
                sign = -sign
        assert sign == 1
        scale = 2 if kind == "s" else 1
        assert (x,y) in ((scale*p,scale*q),(-scale*p,-scale*q))
        p += q
        matrix = Matrix([[1-p*q,p*p],[-q*q,1+p*q]])
        product *= matrix**(4 if kind == "s" else 1)
    assert product == eye(2)
    assert Matrix([[3,2],[1,1]]).det() == 1
    print("Section 8: all fourteen rank-two factors, identity product and determinant-one pair verified")


if __name__ == "__main__":
    verify_finite_images()
    verify_rank_two()
