# Lantern substitutions on a Dolgachev surface

Computational supplement to *Lantern Substitutions in a Genus-Two Fibration
on a Dolgachev Surface* by Anar Akhmedov and Ludmil Katzarkov. The scripts
use the Gurtas five-chain marking of Section 7 and the monodromy basis
of Section 8.

## Run the checks

Use Python 3 and install the pinned dependencies in a virtual environment.

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python verify_lanterns.py
python verify_cyclic.py
python pi1/compute_orbifold.py
python pi1/verify_reduction.py
python verify_monodromy.py
```

| File | Calculation |
|---|---|
| `verify_lanterns.py` | Both lantern identities for the original Gurtas gluing, the full first-stage word, the 27 moves, the geometric cut system, and the integral lift and Smith form |
| `verify_cyclic.py` | Geometric cut systems for orders 2, 6, 10, 14, integral vanishing-cycle matrices and Smith forms, the two mod-two checks, and the orbifold relators quoted for the three modified gluings |
| `pi1/compute_orbifold.py` | Exact transport of all fourteen orbifold relators, including the separating factors |
| `pi1/verify_reduction.py` | Replay of the 307-step and 3,303-step certificates for the original order-two example, including the reverse map onto the Klein four-group |
| `verify_monodromy.py` | Orders modulo two and four, the kernel equation, and the fourteen rank-two monodromy factors for the order-two example |

The original certificates are in `pi1/ns_seed.json` and
`pi1/reduction.json`. Their input is `pi1/orbifold_relators.json`.
To write relators for a modified gluing, specify a separate output file,
so the input to the original certificates stays available.

```sh
python pi1/compute_orbifold.py --order 6 --output relators_6.json
python pi1/compute_orbifold.py --order 10 --output relators_10.json
python pi1/compute_orbifold.py --order 14 --output relators_14.json
```

The signed chain words act rightmost first. The Hurwitz positions are
zero-based and the moves are applied in their listed order. The geometric
checks use exact curve coordinates on the six-punctured sphere. Integral
homology is computed independently by transvections. The passage to the
full fundamental group for the modified gluings uses the short-relator
arguments in Propositions 7.5 and 7.6. The mod-two check is conditional on
the same sequence exposing a geometric lantern for the power in question.

Sections 2–5 use the Monden–Yabuguchi marking. The trefoil cut-system
argument there uses the embedded curves from that marking and the
geometric proof in the manuscript.
