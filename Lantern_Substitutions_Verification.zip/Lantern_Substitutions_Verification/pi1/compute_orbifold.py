import argparse
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def red(w):
 s=[]
 for x in w:
  if s and s[-1]==x:s.pop()
  else:s.append(x)
 return tuple(s)
def cyclic(w):
 w=red(w)
 while len(w)>1 and w[0]==w[-1]:w=w[1:-1]
 return w

def outer(A):
 while True:
  total=sum(map(len,A));cand=set(w[0] for w in A if w)
  improved=False
  for a in cand:
   B=tuple(mul((a,),w,(a,)) for w in A)
   if sum(map(len,B))<total:A=B;improved=True;break
  if not improved:return A

def mul(*ws):return red(x for w in ws for x in w)
def inv(w):return w[::-1]
def act(A,w):return red(y for x in w for y in A[x-1])
def comp(A,B):return tuple(act(A,w) for w in B)
ID=tuple((i,) for i in range(1,7))
class Auto:
 def __init__(self,a=ID,b=ID):self.a,self.b=outer(a),outer(b)
 def __mul__(self,q):return Auto(comp(self.a,q.a),comp(q.b,self.b))
 def inverse(self):return Auto(self.b,self.a)
 def __call__(self,w):return act(self.a,w)
 def __pow__(self,n):
  if n<0:return self.inverse()**(-n)
  out=Auto()
  for _ in range(n):out=out*self
  return out
T=[]
for i in range(1,6):
 a=list(ID);b=list(ID);a[i-1]=(i,i+1,i);a[i]=(i,);b[i-1]=(i+1,);b[i]=(i+1,i,i+1)
 T.append(Auto(tuple(a),tuple(b)))
def braid(seq):
 A=Auto()
 for j in seq:A=A*(T[j-1] if j>0 else T[-j-1].inverse())
 return A
def arguments():
 parser = argparse.ArgumentParser(description="Transport the vanishing cycles of a cyclic example.")
 parser.add_argument("--order", type=int, choices=(2, 6, 10, 14), default=2)
 parser.add_argument("--output", type=Path, default=ROOT / "orbifold_relators.json")
 return parser.parse_args()

class Curve:
 def __init__(self,w,t,kind='n'):self.w,self.t,self.kind=cyclic(w),t,kind
 def image(self,A,need_twist=True):return Curve(A(self.w),A*self.t*A.inverse() if need_twist else None,self.kind)
C=[Curve((i,i+1),T[i-1]) for i in range(1,6)]
B=C[4].image(braid([1,2,3,4]));L=C[3].image(braid([1,1,2,3]));M=C[2].image(braid([2,1,1,2]))
S=Curve((1,2,3,1,2,3),braid([1,2])**6,'s');phi=braid([1,2]);g=M.t.inverse()
rho=C[4].image(braid([-4]));ep=C[1].image(braid([-3,1,-2,5,4,3]));star=S.image(braid([-2,-3]))
I=ep.image(g);J=rho.image(star.t.inverse()).image(g);K=star.image(ep.t).image(g,False)
args = arguments()
phi = T[4] ** (-(args.order - 2) // 2) * phi
P=[M,S.image(g,False),B.image(g)];Q=[S.image(phi,False),B.image(phi),L.image(phi)]
full=P+P+[I,J,K]+Q+Q
print("Starting geometric word transport",flush=True)
for _ in range(len(full)):
 for j in range(len(full)-1):
  x,y=full[j:j+2]
  if x.kind=='s' and y.kind=='n':full[j:j+2]=[y,x.image(y.t.inverse(),False)]
path=[(3,-1),(2,1),(5,-1),(3,1),(8,-1),(0,1),(6,-1),(8,-1),(5,1),(4,-1),(2,-1),(4,1),(5,-1),(5,-1),(0,-1),(3,-1),(2,-1),(1,-1),(5,-1),(4,-1),(3,-1),(2,-1),(7,-1),(6,-1),(5,-1),(4,-1),(3,-1)]
for k,(i,sg) in enumerate(path):
 x,y=full[i:i+2];full[i:i+2]=[y.image(x.t),x] if sg==1 else [y,x.image(y.t.inverse())]
 print('step',k+1,'max word',max(len(x.w) for x in full),flush=True)
markings = {
 2: [2,-1,4,3,-5,-5,-2],
 6: [2,-1,4,3,-2],
 10: [-4,2,-1,3,-2],
 14: [2,-1,4,3,5,5,5,5,-2],
}
G=braid(markings[args.order])
new=[C[2].image(G.inverse()),M.image(G.inverse()),S.image(G.inverse(),False)]
print('new relators',[x.w for x in new],flush=True)
rel=[x.w for x in full[4:]]+[x.w for x in new]
out={'relations':[list(w) for w in rel],'kinds':[x.kind for x in full[4:]+new], 'new_words':[list(x.w)for x in new]}
args.output.write_text(json.dumps(out,indent=2))
print('DONE lengths',[len(w) for w in rel])
